# Credits

- **Original patcher base and patching workflow:** Darabat
- **Fork branding, project organization, and new offline feature definitions:** Rise Of Cybertron Studio
- **Project:** Independent Transformers: Forged to Fight offline revival patcher

The current build script writes these credits into Android application metadata and changes the launcher label. This does **not** yet add a visible Credits screen inside the app. A visible Settings/Credits screen requires modifying the app's UI code/resources and testing the rebuilt APK.
