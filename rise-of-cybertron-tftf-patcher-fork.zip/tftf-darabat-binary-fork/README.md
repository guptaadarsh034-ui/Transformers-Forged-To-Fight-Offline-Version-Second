# Rise Of Cybertron Studio — TFTF Revival Patcher Fork

This is an Android-phone-friendly GitHub Actions project using the uploaded Darabat patcher APK as its binary baseline.

## Current automated changes
- Keeps the original package ID and existing patcher code/assets as the baseline.
- Changes the launcher label to `Rise Of Cybertron Studio — TFTF Revival Patcher`.
- Sets version name to `0.2.0-roc`.
- Adds Android manifest metadata crediting Darabat for the patcher base and Rise Of Cybertron Studio for the fork/new feature definitions.
- Rebuilds, aligns, signs with a temporary test key, verifies APK integrity, and uploads the artifact.
- Validates local-only crystal/store/progression JSON definitions.

## Included offline feature definitions
- `offline-systems/crystals.json`: Scout and Elite crystal reward tables.
- `offline-systems/store.json`: local-only store catalogue; no real-money billing and no network requests.
- `offline-systems/progression.json`: example local inventory and progression reward rules.

These JSON files are **design data only**. The original patcher does not automatically load them, so they are not yet playable features inside TFTF. The current automated changes also do not redesign the actual in-app screens or add a visible Credits page. Those require real UI-code changes and a successful device test.

## Build from Android
1. Create a private GitHub repository.
2. Upload the contents of this project ZIP, including `vendor/darabat-patcher-reference.apk`.
3. Commit/push, then open the repository's Actions tab.
4. Run `Build TFTF patcher fork`.
5. Download the `tftf-patcher-fork-apk` artifact from a successful run.

The workflow's signing key is temporary and regenerated per run. This is suitable for testing, not stable upgrade signing. If replacing an existing installation signed with another key, Android may require uninstalling it first.

## Redistribution
Keep the repository private unless the permission you described explicitly covers redistributing the original APK and bundled assets.
