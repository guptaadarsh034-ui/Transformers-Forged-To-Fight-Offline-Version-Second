#!/usr/bin/env python3
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("usage: patch_manifest.py <decoded AndroidManifest.xml>")

path = Path(sys.argv[1])
tree = ET.parse(path)
root = tree.getroot()
android = "{http://schemas.android.com/apk/res/android}"
app = root.find("application")
if app is None:
    raise SystemExit("AndroidManifest.xml has no <application> element")

# Keep the original package ID and launch flow to avoid breaking the patcher.
app.set(android + "label", "Rise Of Cybertron Studio — TFTF Revival Patcher")
root.set(android + "versionName", "0.2.0-roc")

metadata = {
    "org.riseofcybertron.tftf.FORK_NAME": "Rise Of Cybertron Studio",
    "org.riseofcybertron.tftf.PATCHER_BASE_CREDIT": "Darabat",
    "org.riseofcybertron.tftf.NEW_FEATURES_CREDIT": "Rise Of Cybertron Studio",
    "org.riseofcybertron.tftf.PROJECT_TYPE": "Independent offline revival patcher",
}
for item in list(app.findall("meta-data")):
    if item.get(android + "name") in metadata:
        app.remove(item)
for name, value in metadata.items():
    item = ET.SubElement(app, "meta-data")
    item.set(android + "name", name)
    item.set(android + "value", value)

tree.write(path, encoding="utf-8", xml_declaration=True)
print("Applied fork label, version, and credit metadata; retained original package ID.")
