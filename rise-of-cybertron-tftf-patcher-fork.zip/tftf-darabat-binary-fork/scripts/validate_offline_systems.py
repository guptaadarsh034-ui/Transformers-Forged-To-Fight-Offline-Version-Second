#!/usr/bin/env python3
import json
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else "offline-systems")
def load(name):
    return json.loads((root / name).read_text(encoding="utf-8"))

crystals = load("crystals.json")
store = load("store.json")
progression = load("progression.json")

assert crystals.get("offlineOnly") is True
assert store.get("offlineOnly") is True
assert store.get("noRealMoney") is True
assert store.get("noNetworkRequests") is True
assert progression.get("offlineOnly") is True

crystal_ids = {c["id"] for c in crystals["crystals"]}
assert len(crystal_ids) == len(crystals["crystals"])
for c in crystals["crystals"]:
    assert c["cost"]["amount"] >= 0
    total = sum(r["weight"] for r in c["rewards"])
    assert total == 100, f'{c["id"]}: reward weights total {total}, expected 100'
    assert all(r["min"] >= 0 and r["max"] >= r["min"] for r in c["rewards"])

item_ids = {i["id"] for i in store["items"]}
assert len(item_ids) == len(store["items"])
for item in store["items"]:
    assert item["price"] >= 0 and item["quantity"] > 0
    if item["category"] == "crystal":
        assert item["id"] in crystal_ids, f'unknown crystal item: {item["id"]}'

print(f"Offline systems OK: {len(crystal_ids)} crystal types, {len(item_ids)} store items")
