#!/usr/bin/env python3
import sys
import zipfile
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("usage: verify_apk.py <apk>")

apk = Path(sys.argv[1])
if not apk.is_file() or apk.stat().st_size < 1_000_000:
    raise SystemExit("APK is missing or unexpectedly small")

with zipfile.ZipFile(apk) as z:
    bad = z.testzip()
    if bad:
        raise SystemExit(f"ZIP integrity failure at {bad}")
    names = set(z.namelist())

required = [
    "classes.dex",
    "assets/tftf_payload.bin",
    "assets/libdothook-arm64.bin",
    "assets/libdothook-armv7.bin",
    "AndroidManifest.xml",
]
missing = [name for name in required if name not in names]
if missing:
    raise SystemExit("Missing expected baseline entries: " + ", ".join(missing))

print(f"APK archive integrity OK: {apk.stat().st_size} bytes")
print("Required baseline patcher assets are present.")
