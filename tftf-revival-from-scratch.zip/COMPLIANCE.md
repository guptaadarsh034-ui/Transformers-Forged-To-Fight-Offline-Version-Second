# Safety and project boundaries

- Use only game copies and files you are authorized to modify.
- Keep original APKs and user data backed up.
- Do not commit APKs, signing keys, private certificates, account tokens, or proprietary game assets.
- Never claim offline support until the target version has been tested.
- Treat unknown patch offsets and binary payloads as untrusted; validate file type, size, version, and architecture before use.
- The current starter app does not alter game files or communicate with any server.
