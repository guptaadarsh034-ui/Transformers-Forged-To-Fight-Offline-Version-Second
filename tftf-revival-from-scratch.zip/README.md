# TFTF Offline Revival — Fresh Starter Project

A clean, Android-first starter project inspired by the *structure* of the Darabat TFTF APK patcher. This repository does not contain Darabat's source code and does not yet patch a game APK.

## Current status

- Native Android app scaffold (Kotlin + Gradle)
- Simple landing screen and project status
- GitHub Actions workflow to compile a debug APK
- Safe, local-only project foundation
- No bundled game APK, proprietary game assets, signing keys, or extracted compiled payloads

## Important

The reference patcher APK is compiled software. Its internal resources can inform analysis, but they are not equivalent to the original source project. Game-specific patching requires a verified understanding of the target game version, patch offsets/signatures, ABI, and required files. Do not distribute copyrighted game files or use this project to bypass access controls.

## Build

Open the `android/` folder in Android Studio, or push this project to GitHub and run the **Build Android starter** workflow. The workflow uploads an unsigned debug APK artifact.

## Planned milestones

1. Confirm package/version/ABI of a user-owned game installation.
2. Document the reference patcher's supported inputs and output behavior.
3. Implement validation and backup/restore before any binary modification.
4. Add only version-specific, reproducible patch logic after its assumptions are verified.
5. Test the resulting app and game on a device.

The current app is a starter shell, not a finished offline revival patcher.
