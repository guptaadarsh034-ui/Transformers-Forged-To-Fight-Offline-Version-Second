package org.tftf.offlinerevival

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }

        fun addText(value: String, size: Float, bold: Boolean = false) {
            val view = TextView(this).apply {
                text = value
                textSize = size
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }
            content.addView(
                view,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        addText("TFTF Offline Revival", 26f, true)
        addText("Fresh Android project • v0.1.0", 15f)
        addText(
            "Starter app only. No game files have been modified.",
            17f,
            true
        )
        addText(
            "Next: inspect and document the reference patcher's supported game version, " +
                "input requirements, and CPU architecture. Then implement validated, " +
                "version-specific functionality with backups.",
            16f
        )
        addText(
            "Status: project scaffold ready\nPatching: not implemented\nNetwork service: not configured",
            14f
        )

        setContentView(ScrollView(this).apply { addView(content) })
    }
}
